from flask import Flask, request, jsonify
from flask_cors import CORS
import openai
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)

openai.api_key = os.getenv("API_KEY")

# ---------- ROUTES ----------

@app.route('/')
@app.route('/')
def home():
    return "<h2 style='color: green;'>Flask backend is running successfully!</h2>"

@app.route("/explain_code", methods=["POST"])
def explain_code():
    try:
        data = request.get_json()
        code = data.get("code", "")
        mode = data.get("mode", "simple")

        prompt = f"Explain this code in {mode} mode:\n\n{code}"

        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
        )

        explanation = response["choices"][0]["message"]["content"]
        return jsonify({"explanation": explanation})

    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/api/data')
def get_data():
    return jsonify({"data": "This is data from Flask backend!"})


# ---------- MAIN ----------
if __name__ == "__main__":
    app.run(debug=True)
